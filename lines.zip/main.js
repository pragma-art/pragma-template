(function () {
  'use strict';

  /**
   * A set of random utilities.
   *
   * The randomizer is built in two parts:
   *
   * - Uses two murmur2 32-bit hashes with different seeds
   *   on the set of input bytes (i.e. the token hash) to get a 64-bit value
   * - Uses PCG to get a random 0..1 value, extracted from Jacob Rus' notebook
   *
   * See here for more:
   * https://gist.github.com/mattdesl/779daf4c9fa72e21733f9db928f993aa
   * https://github.com/mattdesl/canvas-sketch-util/blob/master/random.js
   */

  // Note that the index order [0, 1, 2, 3] is little-endian
  const eps = Math.pow(2, -32),
    m0 = 0x7f2d,
    m1 = 0x4c95,
    m2 = 0xf42d,
    m3 = 0x5851, // 6364136223846793005
    a0 = 0x814f,
    a1 = 0xf767,
    a2 = 0x7b7e,
    a3 = 0x1405; // 1442695040888963407

  const state = new Uint16Array(4);
  const dv = new DataView(state.buffer);

  // random value between 0..1
  const value = () => {
    // Advance internal state
    const s0 = state[0],
      s1 = state[1],
      s2 = state[2],
      s3 = state[3],
      new0 = (a0 + m0 * s0) | 0,
      new1 = (a1 + m0 * s1 + (m1 * s0 + (new0 >>> 16))) | 0,
      new2 = (a2 + m0 * s2 + m1 * s1 + (m2 * s0 + (new1 >>> 16))) | 0,
      new3 = a3 + m0 * s3 + (m1 * s2 + m2 * s1) + (m3 * s0 + (new2 >>> 16));
    (state[0] = new0), (state[1] = new1), (state[2] = new2);
    state[3] = new3;

    // Calculate output function (XSH RR), uses old state
    const xorshifted =
        (s3 << 21) + (((s3 >> 2) ^ s2) << 5) + (((s2 >> 2) ^ s1) >> 11),
      out_int32 =
        (xorshifted >>> (s3 >> 11)) | (xorshifted << (-(s3 >> 11) & 31));
    return eps * (out_int32 >>> 0);
  };

  // internally gets a 32-bit from tokenData hash bytes
  const hash32 = (bytes, seed = 0) => {
    // murmur2 32bit
    // https://github.com/garycourt/murmurhash-js/blob/master/murmurhash2_gc.js
    const K = 16;
    const mask = 65535;
    const maskByte = 0xff;
    var m = 0x5bd1e995;
    var l = bytes.length,
      h = seed ^ l,
      i = 0,
      k;
    while (l >= 4) {
      k =
        (bytes[i] & maskByte) |
        ((bytes[++i] & maskByte) << 8) |
        ((bytes[++i] & maskByte) << 16) |
        ((bytes[++i] & maskByte) << 24);
      k = (k & mask) * m + ((((k >>> K) * m) & mask) << K);
      k ^= k >>> 24;
      k = (k & mask) * m + ((((k >>> K) * m) & mask) << K);
      h = ((h & mask) * m + ((((h >>> K) * m) & mask) << K)) ^ k;
      l -= 4;
      ++i;
    }
    switch (l) {
      case 3:
        h ^= (bytes[i + 2] & maskByte) << K;
      case 2:
        h ^= (bytes[i + 1] & maskByte) << 8;
      case 1:
        h ^= bytes[i] & maskByte;
        h = (h & mask) * m + ((((h >>> K) * m) & mask) << K);
    }
    h ^= h >>> 13;
    h = (h & mask) * m + ((((h >>> K) * m) & mask) << K);
    h ^= h >>> 15;
    return h >>> 0;
  };

  // sets the seed to a tokenData hash string "0x..."
  const set_seed = (hash) => {
    const nBytes = ~~((hash.length - 2) / 2);
    const bytes = [];
    for (let j = 0; j < nBytes; j++) {
      const e0 = 2 + 2 * j;
      bytes.push(parseInt(hash.slice(e0, e0 + 2), 16));
    }

    // to keep it simple, we just use 32bit murmur2 with two different seeds
    const seed_a = 1690382925;
    const seed_b = 72970470;
    const lower = hash32(bytes, seed_a);
    const upper = hash32(bytes, seed_b);
    dv.setUint32(0, lower);
    dv.setUint32(4, upper);
  };

  // random value between min (inclusive) and max (exclusive)
  const range = (min, max) => {
    if (max === undefined) {
      max = min;
      min = 0;
    }
    return value() * (max - min) + min;
  };

  // random value between min (inclusive) and max (exclusive), then floored
  const rangeFloor = (min, max) => Math.floor(range(min, max));

  const rectangles = [];

  function setup() {
    // Set the hash for it to work with pragma
    set_seed(hash);
    randomSeed(rangeFloor(1e18));

    // Create a canvas
    createCanvas(windowWidth, windowHeight);

    // Disable loop since we are doing a static artwork
    noLoop();

    const rectangleCount = 10;
    for (let i = 0; i < rectangleCount; i++) {
      // Randomly place some rectangles within -1..1 space
      const shrink = 0.5;
      const position = [random(-1, 1) * shrink, random(-1, 1) * shrink];
      // Create a random 0..1 scale for the rectangles
      const scale = random(0.5, 1);
      const size = [random(0, 1) * scale, random(0, 1) * scale];
      rectangles.push({
        position,
        size,
      });
    }
  }

  function draw() {
    background(51);

    strokeJoin(MITER);
    rectMode(CENTER);
    noFill();
    stroke(255);

    const minDim = Math.min(width, height);

    rectangles.forEach((rectangle) => {
      const { position, size } = rectangle;

      // The position and size in -1..1 normalized space
      let [x, y] = position;
      let [w, h] = size;

      // Map -1..1 to screen pixels
      // First we 'push' to save transformation state
      push();

      // Then translate to the center
      translate(width / 2, height / 2);

      // And scale the context by half the size of the screen
      // We use a square ratio so that the lines have even thickness
      scale(minDim / 2, minDim / 2);

      // The stroke weight is specified in 0..1 normalized space
      // It will be multiplied by the scale above
      strokeWeight(0.015);

      // now draw the rectangle
      rect(x, y, w, h);

      // and restore the transform for the next rectangle
      pop();
    });
  }

  // ___________________
  function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
  }

  let W = window;
  W.setup = setup;
  W.draw = draw;
  W.windowResized = windowResized;
  W.attributes = {};

})();
